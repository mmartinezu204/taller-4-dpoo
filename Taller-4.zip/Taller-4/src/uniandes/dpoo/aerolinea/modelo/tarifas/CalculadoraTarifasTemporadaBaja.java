package uniandes.dpoo.aerolinea.modelo.tarifas;

import java.util.ArrayList;
import java.util.Collection;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
	protected int COSTO_POR_KM_NATURAL = 600;
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	protected double DESCUENTO_PEQ = 0.02;
	protected double DESCUENTO_MEDIANAS = 0.1;
	protected double DESCUENTO_GRANDES = 0.2;
	
	
	public CalculadoraTarifasTemporadaBaja(double iMPUESTO, int cOSTO_POR_KM_NATURAL, int cOSTO_POR_KM_CORPORATIVO,
			double dESCUENTO_PEQ, double dESCUENTO_MEDIANAS, double dESCUENTO_GRANDES) {
		super(iMPUESTO);
		COSTO_POR_KM_NATURAL = cOSTO_POR_KM_NATURAL;
		COSTO_POR_KM_CORPORATIVO = cOSTO_POR_KM_CORPORATIVO;
		DESCUENTO_PEQ = dESCUENTO_PEQ;
		DESCUENTO_MEDIANAS = dESCUENTO_MEDIANAS;
		DESCUENTO_GRANDES = dESCUENTO_GRANDES;
	}
	@Override
	
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		if (cliente.getTipoCliente() == "Natural") {
			int KM = calcularDistanciaVuelo(vuelo.getRuta());
			return COSTO_POR_KM_NATURAL*KM;
		} 
		else if (cliente.getTipoCliente() == "Corporativo") {
			int KM = calcularDistanciaVuelo(vuelo.getRuta());
			return COSTO_POR_KM_CORPORATIVO*KM;
		}
		return 0;
	}
	@Override
	protected int calcularDistanciaVuelo(Ruta ruta) {
		// TODO Auto-generated method stub
		return super.calcularDistanciaVuelo(ruta);
	}
	@Override
	protected double calcularPorcentajeDescuento(Cliente cliente) {
		// TODO Auto-generated method stub
		if (cliente.getTipoCliente() == "Natural") {
			return 0;
		}
		else if (cliente.getTipoCliente() == "Corporativo") {
			Collection<ClienteCorporativo> cc = new ArrayList<ClienteCorporativo>();
			for (ClienteCorporativo corpo: cc) {
				if(corpo.getIdentificador() == cliente.getIdentificador()) {
					if (corpo.getTamanoEmpresa() == 1) {
						return DESCUENTO_GRANDES;
					}
					else if (corpo.getTamanoEmpresa() == 2) {
						return DESCUENTO_MEDIANAS;
					}
					else if (corpo.getTamanoEmpresa() == 3) {
						return DESCUENTO_PEQ;
					}
					
				}
			}
			
		}
		return 0;
	}
	
	
	@Override
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		return super.calcularTarifa(vuelo, cliente);
	}
	@Override
	protected int calcularValorImpuestos(int costoBase) {
		// TODO Auto-generated method stub
		return super.calcularValorImpuestos(costoBase);
	}
	
	
}
