package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	public double IMPUESTO = 0.28;
	
	public CalculadoraTarifas(double iMPUESTO) {
		super();
		IMPUESTO = iMPUESTO;
	}

	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		return (int) ((calcularCostoBase(vuelo, cliente) - calcularPorcentajeDescuento(cliente))*(1+IMPUESTO));
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		return Aeropuerto.calcularDistancia(ruta.getOrigen(), ruta.getDestino());
	}
	
	protected int calcularValorImpuestos(int costoBase) {
		double impuesto = IMPUESTO*costoBase;
		return (int) impuesto;
	}
	
	
}
