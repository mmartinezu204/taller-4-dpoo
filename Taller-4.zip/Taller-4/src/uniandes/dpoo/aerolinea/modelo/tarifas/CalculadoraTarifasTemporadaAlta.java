package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas {
	protected int COSTO_POR_KM = 100;

	
	public CalculadoraTarifasTemporadaAlta(double iMPUESTO) {
		super(iMPUESTO);
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		return super.calcularTarifa(vuelo, cliente);
	}


	@Override
	protected int calcularDistanciaVuelo(Ruta ruta) {
		// TODO Auto-generated method stub
		return super.calcularDistanciaVuelo(ruta);
	}


	@Override
	protected int calcularValorImpuestos(int costoBase) {
		// TODO Auto-generated method stub
		return super.calcularValorImpuestos(costoBase);
	}


	@Override
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		return COSTO_POR_KM*calcularDistanciaVuelo(vuelo.getRuta());
	}


	@Override
	protected double calcularPorcentajeDescuento(Cliente cliente) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
