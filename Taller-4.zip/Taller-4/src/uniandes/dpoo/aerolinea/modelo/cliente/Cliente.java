	package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	private List<Tiquete> tiquetesSinUsar = new ArrayList<Tiquete>();
	private List<Tiquete> tiquetesUsados = new ArrayList<Tiquete>();
	
	
	public Cliente() {
		super();
	}
	
	
	
	public List<Tiquete> getTiquetesSinUsar() {
		return tiquetesSinUsar;
	}



	public void setTiquetesSinUsar(List<Tiquete> tiquetesSinUsar) {
		this.tiquetesSinUsar = tiquetesSinUsar;
	}



	public List<Tiquete> getTiquetesUsados() {
		return tiquetesUsados;
	}



	public void setTiquetesUsados(List<Tiquete> tiquetesUsados) {
		this.tiquetesUsados = tiquetesUsados;
	}



	public abstract String getTipoCliente();

	public abstract String getIdentificador();


	public void agregarTiquete(Tiquete tiquete) {
		this.tiquetesSinUsar.add(tiquete);	
	}
	
	public int calcularValorTotalTiquetes() {
		int valor = 0;
		for (Tiquete tiquetessin: tiquetesSinUsar) {
			valor = valor + tiquetessin.getTarifa();
		}
		for (Tiquete tiquetesusa: tiquetesUsados) {
			valor = valor + tiquetesusa.getTarifa();
		}
		return valor;
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		for (Tiquete sinUsar:tiquetesSinUsar)
		{
			Vuelo vue= sinUsar.getVuelo();
			if (vue.equals(vuelo) == true)
			{
				this.tiquetesSinUsar.remove(sinUsar);
				this.tiquetesUsados.add(sinUsar);
			}
		}
	}
}
